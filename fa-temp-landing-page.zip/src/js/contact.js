console.log("contact page");
import * as somecss from '../scss/contact.scss';